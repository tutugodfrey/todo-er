#! /bin/bash


# Update server hostname
DB_SERVER_HOSTNAME=${DB_SERVER_HOSTNAME}
DB_SERVER_IP=${DB_SERVER_IP}

if [ DB_SERVER_HOSTNAME ]; then
  hostnamectl set-hostname $DB_SERVER_HOSTNAME
fi;

# Install postgresql server
yum install postgresql-server postgresql-contrib -y;
postgresql-setup initdb;
systemctl enable --now postgresql;
