#! /bin/bash

yum install git -y;
yum install postgresql -y;
yum install nginx -y;
if [ $? -ne 0 ]; then
  amazon-linux-extras install nginx1 -y;
fi

NEW_HOSTNAME=${NEW_HOSTNAME}
STORAGE_SERVER_IP=${STORAGE_SERVER_IP}
STORAGE_SERVER_HOSTNAME=${STORAGE_SERVER_HOSTNAME}
DB_SERVER_HOSTNAME=${DB_SERVER_HOSTNAME}
DB_SERVER_IP=${DB_SERVER_IP}
if [ $NEW_HOSTNAME ]; then
  hostnamectl set-hostname $NEW_HOSTNAME;
fi;

cat >> /etc/hosts <<EOF
$STORAGE_SERVER_IP       $STORAGE_SERVER_HOSTNAME store
$DB_SERVER_IP            $DB_SERVER_HOSTNAME
EOF

yum install -y gcc-c++ make;
curl -sL https://rpm.nodesource.com/setup_15.x | sudo -E bash -;
yum install nodejs -y;
echo "Version of node install is $(node --version)";

git clone https://github.com/tutugodfrey/todo-er;
systemctl enable --now nfs
mkdir /todo-er /data
echo "store:/todo-er /todo-er nfs _netdev 0 0" >> /etc/fstab;
echo "store:/data /data nfs _netdev 0 0" >> /etc/fstab;
until mount -a; do echo "waiting for nfs mount to succeed"; done

cd todo-er;
# npm install;
# cp .env.example .env;
# IP_ADDRESS=$(wget -qO - http://ipecho.net/plain);
# sed -i "s/IP/$IP_ADDRESS/" .env;
# sed -i 's/APPPORT/8080/' .env;
# npm run build;
# npm test;
npm start;
